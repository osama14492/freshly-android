/* FRESHLY offline-first Firebase bridge.
 * Keeps the existing Firebase project and Realtime Database paths unchanged.
 * Local writes are journaled in localStorage and replayed when connectivity returns.
 */
(function () {
  'use strict';
  const TREE_KEY = 'freshly_rtdb_local_cache_v1';
  const QUEUE_KEY = 'freshly_rtdb_write_queue_v1';
  let firebaseConfig = null;
  let realFirebase = (window.firebase && typeof window.firebase.database === 'function') ? window.firebase : null;
  let realApp = null;
  let loadingSdk = false;
  const listeners = [];
  const seen = new Set();

  function readTree() { try { return JSON.parse(localStorage.getItem(TREE_KEY) || '{}') || {}; } catch (_) { return {}; } }
  function writeTree(tree) { try { localStorage.setItem(TREE_KEY, JSON.stringify(tree)); } catch (e) { console.warn('FRESHLY local cache write failed', e); } }
  function parts(path) { return String(path || '').split('/').filter(Boolean); }
  function getPath(path) { let v = readTree(); for (const p of parts(path)) { if (v == null) return null; v = v[p]; } return v === undefined ? null : v; }
  function putPath(path, value, remove) {
    const keys = parts(path); if (!keys.length) return;
    const tree = readTree(); let node = tree;
    for (let i=0;i<keys.length-1;i++) { if (!node[keys[i]] || typeof node[keys[i]] !== 'object') node[keys[i]] = {}; node = node[keys[i]]; }
    if (remove) delete node[keys[keys.length-1]]; else node[keys[keys.length-1]] = value;
    writeTree(tree);
  }
  function enqueue(op) { let q=[]; try { q=JSON.parse(localStorage.getItem(QUEUE_KEY)||'[]'); } catch(_){} q.push(Object.assign({qid:'q_'+Date.now()+'_'+Math.random().toString(36).slice(2)},op)); localStorage.setItem(QUEUE_KEY,JSON.stringify(q)); }
  function snapshot(value, key) { return { key: key || null, val: () => value, exists: () => value !== null && value !== undefined, forEach: fn => { if (!value || typeof value !== 'object') return false; for (const k of Object.keys(value)) if (fn(snapshot(value[k],k)) === true) return true; return false; } }; }
  function onlineRef(path) { try { return realFirebase && realApp ? realFirebase.database().ref(path) : null; } catch (_) { return null; } }
  function notifyLocal(path, event, key, value) {
    listeners.forEach(l => {
      if (l.event !== event) return;
      if (l.path === path || (event === 'child_added' && path === l.path)) {
        const token=l.path+'|'+key+'|'+event; if (seen.has(token)) return; seen.add(token); l.callback(snapshot(value,key));
      }
    });
  }
  function applyLocal(op) {
    if (op.type === 'set') putPath(op.path,op.value,false);
    else if (op.type === 'update') { const old=getPath(op.path)||{}; putPath(op.path,Object.assign({},old,op.value||{}),false); }
    else if (op.type === 'remove') putPath(op.path,null,true);
  }
  async function flushQueue() {
    if (!navigator.onLine || !realFirebase || !realApp) return;
    let q=[]; try { q=JSON.parse(localStorage.getItem(QUEUE_KEY)||'[]'); } catch(_){}
    while (q.length && navigator.onLine) {
      const op=q[0];
      try {
        const ref=realFirebase.database().ref(op.path);
        if (op.type==='set') await ref.set(op.value);
        else if (op.type==='update') await ref.update(op.value||{});
        else if (op.type==='remove') await ref.remove();
        q.shift(); localStorage.setItem(QUEUE_KEY,JSON.stringify(q));
      } catch (e) { console.warn('FRESHLY sync paused; queued write retained',e); break; }
    }
    window.dispatchEvent(new CustomEvent('freshly-sync-state',{detail:{pending:q.length}}));
  }
  function attachRemote(l) {
    const ref=onlineRef(l.path); if (!ref || l.remoteAttached) return;
    l.remoteAttached=true;
    try { ref.on(l.event, snap => {
      const val=snap.val();
      if (l.event==='child_added' && val != null) { putPath(l.path+'/'+snap.key,val,false); const token=l.path+'|'+snap.key+'|'+l.event; if (!seen.has(token)) { seen.add(token); l.callback(snapshot(val,snap.key)); } }
      else if (l.event==='value') { putPath(l.path,val,false); l.callback(snapshot(val,snap.key)); }
    }, err => { l.remoteAttached=false; console.warn('Firebase listener paused',err); }); } catch (_) { l.remoteAttached=false; }
  }
  function makeRef(path) {
    path=String(path||'');
    return {
      set(value) { putPath(path,value,false); enqueue({type:'set',path,value}); flushQueue(); return Promise.resolve(); },
      update(value) { const old=getPath(path)||{}; putPath(path,Object.assign({},old,value||{}),false); enqueue({type:'update',path,value}); flushQueue(); return Promise.resolve(); },
      remove() { putPath(path,null,true); enqueue({type:'remove',path}); flushQueue(); return Promise.resolve(); },
      on(event, callback) {
        const l={path,event,callback,remoteAttached:false}; listeners.push(l);
        if (event==='child_added') { const children=getPath(path)||{}; Object.keys(children).forEach(k=>{ const token=path+'|'+k+'|'+event; if (!seen.has(token)) { seen.add(token); callback(snapshot(children[k],k)); } }); }
        else if (event==='value') callback(snapshot(getPath(path),null));
        attachRemote(l); return callback;
      },
      off(event, callback) { for(let i=listeners.length-1;i>=0;i--) if(listeners[i].path===path && (!event||listeners[i].event===event) && (!callback||listeners[i].callback===callback)) listeners.splice(i,1); try { const r=onlineRef(path); if(r) r.off(event,callback); } catch(_){} },
      once(event) {
        const r=onlineRef(path);
        if (r && navigator.onLine) return r.once(event).then(s=>{putPath(path,s.val(),false);return snapshot(s.val(),s.key);}).catch(()=>snapshot(getPath(path),null));
        return Promise.resolve(snapshot(getPath(path),null));
      }
    };
  }
  function installFacade() {
    const facade={
      get apps(){ return realFirebase && realFirebase.apps ? realFirebase.apps : (realApp ? [realApp] : []); },
      initializeApp(config){ firebaseConfig=config; if(realFirebase && typeof realFirebase.initializeApp==='function') { try { realApp=realFirebase.apps&&realFirebase.apps.length?realFirebase.app():realFirebase.initializeApp(config); } catch(_) { try { realApp=realFirebase.app(); } catch(__){} } } else { realApp={options:config,name:'[DEFAULT]'}; } return realApp; },
      database(){ return {ref:makeRef}; }
    };
    window.firebase=facade;
  }
  installFacade();
  async function loadSdk() {
    if (realFirebase && realApp) { listeners.forEach(attachRemote); flushQueue(); return; }
    if (loadingSdk || !navigator.onLine) return;
    loadingSdk=true;
    try {
      // Let the official compat SDK create its own namespace, then restore our facade.
      window.firebase=undefined;
      await new Promise((resolve,reject)=>{ const s=document.createElement('script'); s.src='https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js'; s.onload=resolve; s.onerror=reject; document.head.appendChild(s); });
      await new Promise((resolve,reject)=>{ const s=document.createElement('script'); s.src='https://www.gstatic.com/firebasejs/9.22.0/firebase-database-compat.js'; s.onload=resolve; s.onerror=reject; document.head.appendChild(s); });
      realFirebase=window.firebase;
      if (realFirebase && firebaseConfig) { realApp=realFirebase.apps&&realFirebase.apps.length?realFirebase.app():realFirebase.initializeApp(firebaseConfig); }
      installFacade(); listeners.forEach(attachRemote); await flushQueue();
    } catch(e) { installFacade(); console.warn('Firebase SDK unavailable; FRESHLY remains in offline mode',e); }
    finally { loadingSdk=false; }
  }
  window.addEventListener('online',()=>{loadSdk();});
  window.addEventListener('offline',()=>window.dispatchEvent(new CustomEvent('freshly-sync-state',{detail:{offline:true}})));
  window.addEventListener('load',()=>{ if(navigator.onLine) loadSdk(); });
  window.addEventListener('freshly-sync-state',e=>{ const el=document.getElementById('freshlyConnectionStatus'); if(el) el.textContent=navigator.onLine ? ('متصل · مزامنة معلقة: '+(e.detail&&e.detail.pending||0)) : 'بدون إنترنت · الحفظ محلي'; });
  window.FRESHLY_OFFLINE={flush:()=>loadSdk(),pending:()=>{try{return JSON.parse(localStorage.getItem(QUEUE_KEY)||'[]').length}catch(_){return 0}},getLocal:path=>getPath(path)};
})();
