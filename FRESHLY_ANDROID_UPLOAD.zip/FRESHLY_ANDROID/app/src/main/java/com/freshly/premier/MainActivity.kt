package com.freshly.premier

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var home: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 40, 28, 40)
            setBackgroundColor(Color.rgb(12,14,19))
        }
        val title = TextView(this).apply {
            text = "FRESHLY"
            textSize = 34f
            setTextColor(Color.rgb(212,175,55))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "POS  •  DIGITAL MENU"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 34)
        }
        home.addView(title)
        home.addView(subtitle)
        home.addView(makeButton("الكاشير", "file:///android_asset/cashier.html"))
        home.addView(makeButton("المنيو الإلكتروني", "file:///android_asset/menu.html"))
        setContentView(home)
    }

    private fun makeButton(label: String, url: String): Button {
        return Button(this).apply {
            text = label
            textSize = 18f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(212,175,55))
            isAllCaps = false
            setOnClickListener { openPage(url) }
            val lp = LinearLayout.LayoutParams(-1, 62)
            lp.setMargins(0, 12, 0, 12)
            layoutParams = lp
        }
    }

    private fun openPage(url: String) {
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(12,14,19))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.loadsImagesAutomatically = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("file:///android_asset/")) return false
                return false
            }
        }
        setContentView(web)
        web.loadUrl(url)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else showHome()
    }
}
